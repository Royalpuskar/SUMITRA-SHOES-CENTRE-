<?php
session_start();
include "../config.php";

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Workspace Dashboard | Sumitra Shoes Centre</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#eef2f3;">

<header class="admin-header">
    <h1>Sumitra Shoes Centre <span class="admin-badge">Admin Dashboard</span></h1>
    <nav>
        <a href="dashboard.php">Control Dashboard</a>
        <a href="add_product.php">Add New Product</a>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['admin_name']); ?>)</a>
    </nav>
</header>

<div class="container" style="margin-top:40px;">
    
    <div class="admin-dashboard-grid">
        
        <!-- Products CRUD Logs List Area -->
        <div class="admin-section">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h3 style="margin:0; border:none; padding:0;">Shoe Products Catalog Inventory</h3>
                <a href="add_product.php" class="btn" style="max-width:180px; padding:8px 12px; background:#2e7d32; font-size:14px;">+ Add New Shoe</a>
            </div>

            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Shoe Name</th>
                        <th>Price Level</th>
                        <th>Category Brand</th>
                        <th>Database Image Path</th>
                        <th>Action Log</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                                <td>Rs. <?php echo number_format($row['price'], 2); ?></td>
                                <td><span style="background-color:#cfd8dc; padding:2px 8px; border-radius:10px; font-size:12px; font-weight:600;"><?php echo htmlspecialchars($row['category']); ?></span></td>
                                <td style="font-family: monospace; font-size:12px; color:#555;"><?php echo htmlspecialchars($row['image']); ?></td>
                                <td>
                                    <a href="delete_product.php?id=<?php echo $row['id']; ?>" class="cart-remove-btn" onclick="return confirm('Do you really intend to remove this product?');">Delete</a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; color:#888;'>No shoe products in database. Add first.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Orders and Fonepay Logging Logs List Area -->
        <div class="admin-section">
            <h3>Registered Customer Orders & Payments Gateway Details</h3>
            
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>User Account</th>
                        <th>Ordered Items Bundle</th>
                        <th>Total Paid Price</th>
                        <th>Gateway Transaction ID</th>
                        <th>Fulfillment</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $order_query = "SELECT orders.*, users.username, users.email FROM orders 
                                    INNER JOIN users ON orders.user_id = users.id 
                                    ORDER BY orders.id DESC";
                    $orders_res = mysqli_query($conn, $order_query);

                    if ($orders_res && mysqli_num_rows($orders_res) > 0) {
                        while ($ord = mysqli_fetch_assoc($orders_res)) {
                            ?>
                            <tr>
                                <td>#<?php echo $ord['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($ord['username']); ?></strong><br>
                                    <span style="font-size:11px; color:#666;"><?php echo htmlspecialchars($ord['email']); ?></span>
                                </td>
                                <td style="font-size:13px; color:#444;"><?php echo htmlspecialchars($ord['items']); ?></td>
                                <td class="text-success">Rs. <?php echo number_format($ord['total'], 2); ?></td>
                                <td style="font-family:monospace; background-color:#eaeaea; font-size:12px; padding:4px 8px; border-radius:4px; font-weight:700;">
                                    <?php echo htmlspecialchars($ord['transaction_id']); ?>
                                </td>
                                <td><span class="text-success">&check; Order Recorded</span></td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; color:#888;'>No transactions logged of customer orders yet.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

</body>
</html>
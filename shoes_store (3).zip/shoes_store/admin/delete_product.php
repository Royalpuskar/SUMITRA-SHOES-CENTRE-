<?php
session_start();
include "../config.php";

// Redirection authorization shield
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Execute DB query operation
    $query = "DELETE FROM products WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php?status=deleted");
        exit();
    } else {
        die("Deletion database error details: " . mysqli_error($conn));
    }
} else {
    header("Location: dashboard.php");
    exit();
}
?>
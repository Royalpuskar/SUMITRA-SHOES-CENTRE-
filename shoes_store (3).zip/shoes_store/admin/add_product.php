<?php
session_start();
include "../config.php";

// Authorization security validation
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$message_type = "";

if (isset($_POST['add'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = floatval($_POST['price']);
    $image = mysqli_real_escape_string($conn, $_POST['image']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    if (empty($name) || empty($price) || empty($image) || empty($category)) {
        $message = "Kindly insert all shoe item parameters!";
        $message_type = "error";
    } else {
        $query = "INSERT INTO products (name, price, image, category) 
                  VALUES ('$name', '$price', '$image', '$category')";
        
        if (mysqli_query($conn, $query)) {
            $message = "Premium shoes successfully enrolled into dynamic SQL inventory!";
            $message_type = "success";
        } else {
            $message = "Database adding process failed: " . mysqli_error($conn);
            $message_type = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log New Shoes | Sumitra Shoes Centre</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#eef2f3;">

<header class="admin-header">
    <h1>Sumitra Shoes Centre <span class="admin-badge">Admin Panel</span></h1>
    <nav>
        <a href="dashboard.php">Control Dashboard</a>
        <a href="add_product.php">Add New Product</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<div class="container" style="margin-top: 40px;">
    <div class="form-container" style="max-width: 650px;">
        <h2>Enroll Premium New Shoe Item</h2>
        <p style="color:#666; font-size:13px; text-align:center; margin-bottom:25px;">Enter shoe specification metrics for automatic HTML catalog generation.</p>

        <?php if (!empty($message)): ?>
            <div class="form-message message-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="add_product.php">
            <div class="form-group">
                <label for="name">Uniform Shoe Product Name</label>
                <input type="text" id="name" name="name" placeholder="e.g. Adidas Purebounce Men Sneaker" required>
            </div>

            <div class="form-group">
                <label for="price">Price Tag Level (Nepali Rupees Rs.)</label>
                <input type="number" step="0.01" id="price" name="price" placeholder="e.g. 4850" required>
            </div>

            <div class="form-group">
                <label for="category">Category Classification</label>
                <select name="category" id="category" style="width:100%; padding:12px; border:1px solid #ccc; border-radius:4px; background:white; font-size:14px;">
                    <option value="Sports">Sports & Athletic</option>
                    <option value="Casual">Urban Casual Sneaker</option>
                    <option value="Formal">Premium Executive Formal</option>
                    <option value="Boots">Rugged Outdoors Boots</option>
                    <option value="School">School Dress Code Uniform</option>
                </select>
            </div>

            <div class="form-group">
                <label for="image">Remote Image Link / JPG Filename</label>
                <input type="text" id="image" name="image" placeholder="runner.jpg or Unsplash picture URL" value="runner.jpg" required>
                <small style="color:#888; font-size:11px; display:block; margin-top:5px;">Can use a standard filename (e.g. sneaker.jpg) or copy-paste any valid web image link.</small>
            </div>

            <button type="submit" name="add" class="btn" style="background:#2e7d32; margin-top:15px;">Register Brand Shoe</button>
        </form>
    </div>
</div>

</body>
</html>
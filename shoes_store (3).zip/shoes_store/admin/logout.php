<?php
session_start();

// Unset admin session parameters
unset($_SESSION['admin']);
unset($_SESSION['admin_name']);

// Destroy session completely if desired, else clear admin states
header("Location: ../index.php");
exit();
?>
<?php
session_start();
include "../config.php";

$message = "";
$message_type = "";

if (isset($_POST['login'])) {
    // Escape standard requests
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $message = "Please fill in all security fields!";
        $message_type = "error";
    } else {
        $query = "SELECT * FROM admins WHERE username = '$username'";
        $res = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($res);

        if ($row && password_verify($password, $row['password'])) {
            $_SESSION['admin'] = $row['id'];
            $_SESSION['admin_name'] = $row['username'];
            header("Location: dashboard.php");
            exit();
        } else {
            $message = "Invalid Admin Credentials!";
            $message_type = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Corner Login | Sumitra Shoes Centre</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body style="background:#eef2f3;">

<header class="admin-header">
    <h1>Sumitra Shoes Centre <span class="admin-badge">Admin Panel</span></h1>
    <nav>
        <a href="../index.php">Customer Website Home</a>
    </nav>
</header>

<div class="container">
    <div class="form-container" style="margin-top: 100px;">
        <h2>Administrative Control Login</h2>
        <p style="text-align:center; color:#666; font-size:13px; margin-bottom:20px;">Use: username: <strong>admin</strong> | password: <strong>admin123</strong> to test</p>

        <?php if (!empty($message)): ?>
            <div class="form-message message-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Admin Username</label>
                <input type="text" id="username" name="username" placeholder="Enter Administrative ID" required>
            </div>

            <div class="form-group">
                <label for="password">Security Password</label>
                <input type="password" id="password" name="password" placeholder="Enter Admin Password" required>
            </div>

            <button type="submit" name="login" class="btn" style="background:#263238;">Authorized Login</button>
        </form>
    </div>
</div>

</body>
</html>